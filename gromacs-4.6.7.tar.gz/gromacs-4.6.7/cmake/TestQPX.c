int main()
{
    vector4double one = vec_splats(1.0);
    vector4double zero = vec_sub(one,one);
    return 0;
}
